import java.util.*;

class Task {
    int id;
    String name;
    String description;

    Task(int id, String name, String description) {
        this.id = id;
        this.name = name;
        this.description = description;
    }
}

public class TaskManager {
    static Scanner sc = new Scanner(System.in);
    static ArrayList<Task> tasks = new ArrayList<>();
    static int nextId = 1;

    public static void main(String[] args) {
        int choice;
        do {
            System.out.println("\n=== Task Manager ===");
            System.out.println("1. Create Task");
            System.out.println("2. View All Tasks");
            System.out.println("3. Update Task");
            System.out.println("4. Delete Task");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1 -> createTask();
                case 2 -> viewTasks();
                case 3 -> updateTask();
                case 4 -> deleteTask();
                case 5 -> System.out.println("Exiting... Thank you!");
                default -> System.out.println("Invalid choice. Try again!");
            }
        } while (choice != 5);
    }

    static void createTask() {
        System.out.print("Enter task name: ");
        String name = sc.nextLine();
        System.out.print("Enter task description: ");
        String desc = sc.nextLine();

        tasks.add(new Task(nextId++, name, desc));
        System.out.println("✅ Task added successfully!");
    }

    static void viewTasks() {
        if (tasks.isEmpty()) {
            System.out.println("No tasks available!");
            return;
        }
        System.out.println("\n--- All Tasks ---");
        for (Task t : tasks) {
            System.out.println("ID: " + t.id + " | Name: " + t.name + " | Description: " + t.description);
        }
    }

    static void updateTask() {
        System.out.print("Enter task ID to update: ");
        int id = sc.nextInt();
        sc.nextLine();
        boolean found = false;

        for (Task t : tasks) {
            if (t.id == id) {
                System.out.print("Enter new task name: ");
                t.name = sc.nextLine();
                System.out.print("Enter new task description: ");
                t.description = sc.nextLine();
                System.out.println("✅ Task updated successfully!");
                found = true;
                break;
            }
        }
        if (!found) System.out.println("Task not found!");
    }

    static void deleteTask() {
        System.out.print("Enter task ID to delete: ");
        int id = sc.nextInt();
        sc.nextLine();

        boolean removed = tasks.removeIf(t -> t.id == id);
        if (removed) System.out.println("✅ Task deleted successfully!");
        else System.out.println("Task not found!");
    }
}
