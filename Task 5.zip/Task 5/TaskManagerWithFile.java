import java.io.*;
import java.util.*;

class Task {
    int id;
    String name;
    String description;

    Task(int id, String name, String description) {
        this.id = id;
        this.name = name;
        this.description = description;
    }

    @Override
    public String toString() {
        return id + "," + name + "," + description;
    }

    static Task fromString(String line) {
        String[] parts = line.split(",", 3);
        return new Task(Integer.parseInt(parts[0]), parts[1], parts[2]);
    }
}

public class TaskManagerWithFile {
    static Scanner sc = new Scanner(System.in);
    static ArrayList<Task> tasks = new ArrayList<>();
    static int nextId = 1;
    static final String FILE_NAME = "tasks.txt";

    public static void main(String[] args) {
        loadTasks();
        int choice;
        do {
            System.out.println("\n=== Task Manager with File Storage ===");
            System.out.println("1. Create Task");
            System.out.println("2. View All Tasks");
            System.out.println("3. Update Task");
            System.out.println("4. Delete Task");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1 -> createTask();
                case 2 -> viewTasks();
                case 3 -> updateTask();
                case 4 -> deleteTask();
                case 5 -> saveTasks();
                default -> System.out.println("Invalid choice. Try again!");
            }
        } while (choice != 5);
    }

    static void createTask() {
        System.out.print("Enter task name: ");
        String name = sc.nextLine();
        System.out.print("Enter task description: ");
        String desc = sc.nextLine();
        tasks.add(new Task(nextId++, name, desc));
        System.out.println("Task added successfully!");
    }

    static void viewTasks() {
        if (tasks.isEmpty()) {
            System.out.println("No tasks available!");
            return;
        }
        System.out.println("\n--- All Tasks ---");
        for (Task t : tasks) {
            System.out.println("ID: " + t.id + " | Name: " + t.name + " | Description: " + t.description);
        }
    }

    static void updateTask() {
        System.out.print("Enter task ID to update: ");
        int id = sc.nextInt();
        sc.nextLine();
        boolean found = false;

        for (Task t : tasks) {
            if (t.id == id) {
                System.out.print("Enter new task name: ");
                t.name = sc.nextLine();
                System.out.print("Enter new task description: ");
                t.description = sc.nextLine();
                System.out.println("Task updated successfully!");
                found = true;
                break;
            }
        }
        if (!found) System.out.println("Task not found!");
    }

    static void deleteTask() {
        System.out.print("Enter task ID to delete: ");
        int id = sc.nextInt();
        sc.nextLine();
        boolean removed = tasks.removeIf(t -> t.id == id);
        if (removed) System.out.println("Task deleted successfully!");
        else System.out.println("Task not found!");
    }

    static void saveTasks() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(FILE_NAME))) {
            for (Task t : tasks) writer.println(t);
            System.out.println(" Tasks saved successfully!");
        } catch (IOException e) {
            System.out.println(" Error saving tasks: " + e.getMessage());
        }
    }

    static void loadTasks() {
        File file = new File(FILE_NAME);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            int maxId = 0;
            while ((line = reader.readLine()) != null) {
                Task t = Task.fromString(line);
                tasks.add(t);
                if (t.id > maxId) maxId = t.id;
            }
            nextId = maxId + 1;
            System.out.println("Tasks loaded successfully!");
        } catch (IOException e) {
            System.out.println("Error loading tasks: " + e.getMessage());
        }
    }
}
