import java.util.Scanner;
import java.util.Random;

public class EasyGuessGame {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random random = new Random();

        int number = random.nextInt(10) + 1;
        int userGuess;
        int chances = 3;

        System.out.println("Welcome to the Guessing Game!");
        System.out.println("I have chosen a number between 1 and 10.");
        System.out.println("You have " + chances + " chances to guess it.");

        for (int i = 1; i <= chances; i++) {
            System.out.print("Chance " + i + " Enter your guess: ");
            userGuess = input.nextInt();

            if (userGuess == number) {
                System.out.println("Great! You guessed it right!");
                break;
            } else if (userGuess < number) {
                System.out.println("Too low! Try a bigger number.");
            } else {
                System.out.println("Too high! Try a smaller number.");
            }

            if (i == chances) {
                System.out.println("Sorry! You used all chances. The number was " + number);
            }
        }

        input.close();
    }
}

